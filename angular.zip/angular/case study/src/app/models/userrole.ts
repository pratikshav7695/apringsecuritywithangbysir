export enum Userrole {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_MANAGER
}
